namespace EStoreWebApp.Entities;

public enum Type{

    WIND,WOODEN,STRING,ELECTRIC,PERCUSSION

}